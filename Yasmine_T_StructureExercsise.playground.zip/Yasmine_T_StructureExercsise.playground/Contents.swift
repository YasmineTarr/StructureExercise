import UIKit

struct carEngines {
   var engine1 = "V4"
   var engine2 = "V6"
   var engine3 = "V8"
}

let engines = carEngines()
print("The first engine selection is \(engines.engine1)")
print("The second engine selection is  \(engines.engine2)")
print("The third engine selection is  \(engines.engine3)")
